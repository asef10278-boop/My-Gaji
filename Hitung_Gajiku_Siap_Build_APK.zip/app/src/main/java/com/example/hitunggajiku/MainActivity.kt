package com.example.hitunggajiku

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class WorkEntry(val date: String, val hours: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { SalaryScreen() } }
    }
}

@Composable
fun SalaryScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("salary_data", 0) }
    var rateText by remember { mutableStateOf(prefs.getInt("rate", 15000).toString()) }
    var hoursText by remember { mutableStateOf("") }
    var entries by remember {
        mutableStateOf(run {
            val arr = JSONArray(prefs.getString("entries", "[]") ?: "[]")
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                WorkEntry(o.getString("date"), o.getDouble("hours"))
            }
        })
    }
    var message by remember { mutableStateOf("") }

    fun persist() {
        val arr = JSONArray()
        entries.forEach {
            arr.put(JSONObject().put("date", it.date).put("hours", it.hours))
        }
        prefs.edit()
            .putString("entries", arr.toString())
            .putInt("rate", rateText.toIntOrNull() ?: 15000)
            .apply()
    }

    val rate = rateText.toLongOrNull()?.coerceAtLeast(0) ?: 0L
    val totalHours = entries.sumOf { it.hours }
    val currency = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
        maximumFractionDigits = 0
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Hitung Gajiku", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Kalkulator gaji per jam", color = MaterialTheme.colorScheme.onSurfaceVariant)

        OutlinedTextField(
            value = rateText,
            onValueChange = { rateText = it.filter(Char::isDigit); persist() },
            label = { Text("Tarif per jam (Rp)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = hoursText,
            onValueChange = { hoursText = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
            label = { Text("Jam kerja hari ini") },
            placeholder = { Text("Contoh: 8 atau 7,5") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Button(
            onClick = {
                val h = hoursText.replace(',', '.').toDoubleOrNull()
                if (h == null || h <= 0 || h > 24 || rate <= 0) {
                    message = "Masukkan jam (0–24) dan tarif yang valid."
                } else {
                    val date = SimpleDateFormat("dd-MM-yyyy", Locale("id", "ID")).format(Date())
                    entries = entries + WorkEntry(date, h)
                    hoursText = ""
                    message = "Jam kerja berhasil disimpan."
                    persist()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Simpan jam kerja") }

        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Total jam kerja", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${"%.2f".format(Locale.US, totalHours)} jam", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                HorizontalDivider()
                Text("Total gaji", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(currency.format((totalHours * rate).toLong()), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Riwayat kerja", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            TextButton(onClick = {
                entries = emptyList()
                persist()
                message = "Semua riwayat dihapus."
            }) { Text("Reset") }
        }

        if (entries.isEmpty()) {
            Text("Belum ada catatan kerja.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f, fill = false),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(entries.reversed()) { _, entry ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(entry.date, fontWeight = FontWeight.SemiBold)
                                Text("${entry.hours} jam × ${currency.format(rate)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(currency.format((entry.hours * rate).toLong()), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        Text("Data tersimpan di perangkat ini.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
