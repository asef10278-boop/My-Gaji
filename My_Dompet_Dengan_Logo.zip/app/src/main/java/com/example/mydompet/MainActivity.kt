package com.example.mydompet

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class WorkEntry(val date: String, val hours: Double)
data class ExpenseEntry(val date: String, val note: String, val category: String, val amount: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { MyDompetApp() } }
    }
}

@Composable
fun MyDompetApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("my_dompet_data", 0) }
    var rateText by remember { mutableStateOf(prefs.getInt("rate", 15000).toString()) }
    var hoursText by remember { mutableStateOf("") }
    var expenseAmount by remember { mutableStateOf("") }
    var expenseNote by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Makan") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }

    var workEntries by remember {
        mutableStateOf(run {
            val a = JSONArray(prefs.getString("work_entries", "[]") ?: "[]")
            List(a.length()) { i ->
                val o = a.getJSONObject(i)
                WorkEntry(o.getString("date"), o.getDouble("hours"))
            }
        })
    }
    var expenses by remember {
        mutableStateOf(run {
            val a = JSONArray(prefs.getString("expenses", "[]") ?: "[]")
            List(a.length()) { i ->
                val o = a.getJSONObject(i)
                ExpenseEntry(o.getString("date"), o.getString("note"), o.getString("category"), o.getLong("amount"))
            }
        })
    }

    fun saveAll() {
        val w = JSONArray()
        workEntries.forEach { w.put(JSONObject().put("date", it.date).put("hours", it.hours)) }
        val e = JSONArray()
        expenses.forEach { e.put(JSONObject().put("date", it.date).put("note", it.note).put("category", it.category).put("amount", it.amount)) }
        prefs.edit().putString("work_entries", w.toString()).putString("expenses", e.toString())
            .putInt("rate", rateText.toIntOrNull() ?: 15000).apply()
    }

    val rate = rateText.toLongOrNull()?.coerceAtLeast(0) ?: 0L
    val totalHours = workEntries.sumOf { it.hours }
    val income = (totalHours * rate).toLong()
    val spent = expenses.sumOf { it.amount }
    val currency = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0; message = "" }, icon = { Text("🏠") }, label = { Text("Ringkasan") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1; message = "" }, icon = { Text("💼") }, label = { Text("Gaji") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2; message = "" }, icon = { Text("🛍️") }, label = { Text("Pengeluaran") })
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("My Dompet", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            when (selectedTab) {
                0 -> {
                    Text("Ringkasan keuangan", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    SummaryCard("Total pemasukan", currency.format(income))
                    SummaryCard("Total pengeluaran", currency.format(spent))
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Sisa uang", color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(currency.format(income - spent), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    Text("Total jam kerja: ${"%.2f".format(Locale.US, totalHours)} jam")
                    Text("Jumlah transaksi: ${expenses.size}")
                    Text("Catatan gaji dan pengeluaran tersimpan di perangkat.")
                }
                1 -> {
                    Text("Catat jam kerja dan hitung gaji")
                    OutlinedTextField(value = rateText, onValueChange = { rateText = it.filter(Char::isDigit); saveAll() }, label = { Text("Tarif per jam (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = hoursText, onValueChange = { hoursText = it.filter { c -> c.isDigit() || c == '.' || c == ',' } }, label = { Text("Jam kerja") }, placeholder = { Text("Contoh: 8 atau 7,5") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = {
                        val h = hoursText.replace(',', '.').toDoubleOrNull()
                        if (h == null || h <= 0 || h > 24 || rate <= 0) message = "Masukkan jam 0–24 dan tarif yang valid."
                        else {
                            val date = SimpleDateFormat("dd-MM-yyyy", Locale("id", "ID")).format(Date())
                            workEntries = workEntries + WorkEntry(date, h); hoursText = ""; saveAll(); message = "Jam kerja berhasil disimpan."
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Simpan jam kerja") }
                    if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
                    SummaryCard("Total jam kerja", "${"%.2f".format(Locale.US, totalHours)} jam")
                    SummaryCard("Total perkiraan gaji", currency.format(income))
                    Text("Riwayat kerja", fontWeight = FontWeight.Bold)
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        itemsIndexed(workEntries.indices.reversed().toList()) { _, idx ->
                            val item = workEntries[idx]
                            Card(Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) { Text(item.date, fontWeight = FontWeight.SemiBold); Text("${item.hours} jam") }
                                    Text(currency.format((item.hours * rate).toLong()))
                                    TextButton(onClick = { workEntries = workEntries.toMutableList().also { it.removeAt(idx) }; saveAll() }) { Text("Hapus") }
                                }
                            }
                        }
                    }
                    TextButton(onClick = { workEntries = emptyList(); saveAll(); message = "Riwayat gaji dihapus." }) { Text("Hapus semua riwayat gaji") }
                }
                2 -> {
                    Text("Catat setiap jajan atau belanja")
                    OutlinedTextField(value = expenseAmount, onValueChange = { expenseAmount = it.filter(Char::isDigit) }, label = { Text("Nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = expenseNote, onValueChange = { expenseNote = it }, label = { Text("Keterangan (contoh: kopi)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }) { Text("Kategori: $category") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            listOf("Makan", "Minum", "Bensin", "Jajan", "Belanja", "Transportasi", "Lainnya").forEach { c ->
                                DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false })
                            }
                        }
                    }
                    Button(onClick = {
                        val amount = expenseAmount.toLongOrNull()
                        if (amount == null || amount <= 0 || expenseNote.isBlank()) message = "Isi nominal dan keterangan terlebih dahulu."
                        else {
                            val date = SimpleDateFormat("dd-MM-yyyy", Locale("id", "ID")).format(Date())
                            expenses = expenses + ExpenseEntry(date, expenseNote.trim(), category, amount)
                            expenseAmount = ""; expenseNote = ""; saveAll(); message = "Pengeluaran berhasil disimpan."
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Simpan pengeluaran") }
                    if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
                    SummaryCard("Total pengeluaran", currency.format(spent))
                    Text("Riwayat pengeluaran", fontWeight = FontWeight.Bold)
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        itemsIndexed(expenses.indices.reversed().toList()) { _, idx ->
                            val item = expenses[idx]
                            Card(Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.note, fontWeight = FontWeight.SemiBold)
                                        Text("${item.date} • ${item.category}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Column {
                                        Text(currency.format(item.amount), fontWeight = FontWeight.Bold)
                                        TextButton(onClick = { expenses = expenses.toMutableList().also { it.removeAt(idx) }; saveAll() }) { Text("Hapus") }
                                    }
                                }
                            }
                        }
                    }
                    TextButton(onClick = { expenses = emptyList(); saveAll(); message = "Semua pengeluaran dihapus." }) { Text("Hapus semua pengeluaran") }
                }
            }
        }
    }
}

@Composable
fun SummaryCard(title: String, value: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}
